public class Main {
    public static void main(String[] args) {
        String repartidor = "Iván Morales Pardo";
        long codigoRuta = 20260924017L;
        char zonaReparto = 'N';
        boolean furgonetaRefrigerada = false;
        double pesoCarga = 319.6;
        int rutaMin = 320;
        String kilometroSalir = "125430";
        String kilometroVolver = "125516";
        //Creamos la variables para el ejercicio
        final double precioCarga = 0.001;
        final double precioGasoleo = 0.14;
        final double seguro = 2.5;
        final double costeRepartidor = 0.24;
        final double margenBeneficio = 15;
        //Creamos la variables que no cambian
        int conversionSalir = 125430;
        int conversionVolver = 125516;
        /*Voy a utilizar esto ya que la conversion no me acuerdo bien como se hacia y para poder seguir con el ejecicio
        lo que hubiera puesto seria : int conversioSalir = (String) kilometroSalir;
        */
        int kmViaje = conversionSalir - conversionVolver;


        int rutaHora = rutaMin / 60;
        int minutosFinal = rutaMin % 60;
        //Calculamos los minutos y las horas
         double costeCarga = pesoCarga * kmViaje * precioCarga;
         double costeGasoleo = kmViaje * precioGasoleo;
         double costeSeguro = (precioCarga * precioGasoleo) * seguro / 100;
         double repartidorPrecio = rutaMin * costeRepartidor;
         //Calculamos los costes
         double precioTotal = costeCarga + costeGasoleo + costeSeguro + repartidorPrecio;
         //
         double margen = precioTotal * margenBeneficio / 100;
         double margenFinal = precioTotal + margen;
        //
        double velocidadMedia = kmViaje * 60 / rutaMin;
        //
        System.out.println(repartidor + codigoRuta + "Camioneta refrigerada: " + furgonetaRefrigerada);
        System.out.println("Coste de carga: " +costeCarga + "coste del gasoleo: " + costeGasoleo +  "coste seguro: " + costeSeguro + "coste repartidor: " + repartidorPrecio + " coste de la ruta " + precioTotal + " margen : " + margen + " coste final " + margenFinal );
        System.out.println("Velocidad media: " + velocidadMedia);


        

    }
}